let contatoSelecionado = null; // null representa "Conversa Geral"

// --- 1. Autenticação (Login) ---
async function realizarLogin() {
    const telefone = document.getElementById('login-telefone').value.trim();
    const senha = document.getElementById('login-senha').value.trim();

    if (!telefone || !senha) {
        alert("Preencha o telefone e a senha!");
        return;
    }

    try {
        const response = await fetch('/auth', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ telefone, senha })
        });

        const data = await response.json();

        if (response.ok && data.authenticated) {
            localStorage.setItem('usuarioLogado', JSON.stringify(data.user));
            window.location.href = 'chat.html';
        } else {
            alert(data.mensagem || "Falha na autenticação.");
        }
    } catch (error) {
        console.error("Erro no login:", error);
        alert("Erro ao conectar ao servidor.");
    }
}

// --- 2. Cadastro (Signin) ---
async function cadastrarUsuario() {
    const apelido = document.getElementById('reg-apelido').value.trim();
    const telefone = document.getElementById('reg-telefone').value.trim();
    const senha = document.getElementById('reg-senha').value.trim();

    if (!apelido || !telefone || !senha) {
        alert("Por favor, preencha todos os campos!");
        return;
    }

    try {
        const response = await fetch('/signin', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ apelido, telefone, senha })
        });

        const data = await response.json();

        if (response.ok && data.sucesso) {
            alert("Conta criada com sucesso! Faça login.");
            window.location.href = 'index.html';
        } else {
            alert(data.mensagem || "Erro ao realizar cadastro.");
        }
    } catch (error) {
        console.error("Erro no cadastro:", error);
        alert("Erro ao conectar ao servidor.");
    }
}

// --- 3. Funções do Chat ---
function verificarAutenticacao() {
    const user = localStorage.getItem('usuarioLogado');
    if (!user) {
        window.location.href = 'index.html';
    }
}

function sair() {
    localStorage.removeItem('usuarioLogado');
    window.location.href = 'index.html';
}

// Carrega os contatos na barra lateral
async function carregarContatos() {
    const userStr = localStorage.getItem('usuarioLogado');
    if (!userStr) return;

    const user = JSON.parse(userStr);
    const listContainer = document.getElementById('chat-list');

    try {
        const response = await fetch(`/contatos?telefone=${encodeURIComponent(user.Telefone)}`);
        const contatos = await response.json();

        listContainer.innerHTML = '';

        // Item padrão: Conversa Geral
        const itemGeral = document.createElement('div');
        itemGeral.className = `chat-item ${contatoSelecionado === null ? 'active' : ''}`;
        itemGeral.innerHTML = `
            <div class="user-avatar" style="background-color: #53bdeb;">G</div>
            <div class="chat-item-info">
                <div class="chat-item-title">Conversa Geral</div>
                <div class="chat-item-sub">Todas as mensagens</div>
            </div>
        `;
        itemGeral.onclick = () => selecionarContato(null, 'Conversa Geral', itemGeral);
        listContainer.appendChild(itemGeral);

        // Adiciona as conversas individuais trazidas do banco
        if (Array.isArray(contatos) && contatos.length > 0) {
            contatos.forEach((contato) => {
                const item = document.createElement('div');
                const isSelected = contatoSelecionado && contatoSelecionado.telefone === contato.Telefone;
                item.className = `chat-item ${isSelected ? 'active' : ''}`;

                const nomeExibicao = contato.Apelido || contato.Telefone;
                const inicial = nomeExibicao.charAt(0).toUpperCase();

                item.innerHTML = `
                    <div class="user-avatar" style="background-color: #00a884;">${inicial}</div>
                    <div class="chat-item-info">
                        <div class="chat-item-title">${nomeExibicao}</div>
                        <div class="chat-item-sub">${contato.Telefone}</div>
                    </div>
                `;

                item.onclick = () => selecionarContato(contato.Telefone, nomeExibicao, item);
                listContainer.appendChild(item);
            });
        }
    } catch (error) {
        console.error("Erro ao carregar contatos:", error);
    }
}

// Seleciona um contato
function selecionarContato(telefone, nome, elemento) {
    if (telefone === null) {
        contatoSelecionado = null;
    } else {
        contatoSelecionado = { telefone, nome };
    }

    document.querySelectorAll('.chat-item').forEach(el => el.classList.remove('active'));
    if (elemento) elemento.classList.add('active');

    document.getElementById('target-name').innerText = nome || 'Conversa Geral';
    document.getElementById('target-avatar').innerText = (nome || 'G').charAt(0).toUpperCase();

    carregarMensagens();
}

// Carrega as mensagens do banco
async function carregarMensagens() {
    const userStr = localStorage.getItem('usuarioLogado');
    if (!userStr) return;

    const user = JSON.parse(userStr);
    const box = document.getElementById('messages-box');

    try {
        const response = await fetch(`/chat?telefone=${encodeURIComponent(user.Telefone)}`);
        const mensagens = await response.json();

        box.innerHTML = '';

        if (!Array.isArray(mensagens) || mensagens.length === 0) {
            box.innerHTML = '<p style="text-align: center; color: #667781; font-size: 13px;">Nenhuma mensagem encontrada.</p>';
            return;
        }

        // Filtra mensagens se houver um contato selecionado, ou exibe todas na "Conversa Geral"
        let mensagensFiltradas = mensagens;
        if (contatoSelecionado !== null) {
            mensagensFiltradas = mensagens.filter(msg => 
                (msg.telefone_remetente === user.Telefone && msg.telefone_destinatario === contatoSelecionado.telefone) ||
                (msg.telefone_remetente === contatoSelecionado.telefone && msg.telefone_destinatario === user.Telefone)
            );
        }

        if (mensagensFiltradas.length === 0) {
            box.innerHTML = '<p style="text-align: center; color: #667781; font-size: 13px;">Nenhuma mensagem nesta conversa.</p>';
            return;
        }

        mensagensFiltradas.forEach(msg => {
            const isEnviada = msg.telefone_remetente === user.Telefone;
            const div = document.createElement('div');
            div.className = `msg ${isEnviada ? 'enviada' : 'recebida'}`;

            const remetenteNome = isEnviada ? 'Você' : (msg.telefone_remetente);

            div.innerHTML = `
                <div class="msg-meta">${remetenteNome}</div>
                <div>${msg.mensagem}</div>
            `;
            box.appendChild(div);
        });

        box.scrollTop = box.scrollHeight;
    } catch (error) {
        console.error("Erro ao carregar mensagens:", error);
    }
}

// Envia a mensagem
async function enviarMensagem() {
    const userStr = localStorage.getItem('usuarioLogado');
    if (!userStr) return;

    const user = JSON.parse(userStr);
    const destinatarioInput = document.getElementById('chat-destinatario').value.trim();
    const mensagem = document.getElementById('chat-mensagem').value.trim();

    const destinatario = destinatarioInput || (contatoSelecionado ? contatoSelecionado.telefone : null);

    if (!destinatario || !mensagem) {
        alert("Informe o número do destinatário e a mensagem.");
        return;
    }

    try {
        const response = await fetch('/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                remetente: user.Telefone,
                destinatario: destinatario,
                mensagem: mensagem
            })
        });

        if (response.ok) {
            document.getElementById('chat-mensagem').value = '';
            document.getElementById('chat-destinatario').value = '';
            
            await carregarContatos();
            carregarMensagens();
        } else {
            alert("Erro ao enviar mensagem.");
        }
    } catch (error) {
        console.error("Erro ao enviar mensagem:", error);
    }
}