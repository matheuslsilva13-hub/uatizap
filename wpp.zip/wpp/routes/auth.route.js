const { Router } = require("express");
const conn = require("../db/connection");

const router = Router();

/**
 * 1. Rota de Autenticação (Login)
 */
router.post("/auth", async (req, res) => {
    try {
        const telefone = req.body?.telefone || req.query?.telefone;
        const senha = req.body?.senha || req.query?.senha;

        if (!telefone || !senha) {
            return res.status(400).json({
                authenticated: false,
                mensagem: "Telefone e senha são obrigatórios."
            });
        }

        const cmd = 'SELECT * FROM utilizadores WHERE Telefone = ? AND Senha = ?';
        const [rows] = await conn.query(cmd, [telefone, senha]);

        if (rows.length > 0) {
            return res.json({
                authenticated: true,
                mensagem: "Autenticado com sucesso!",
                user: rows[0]
            });
        } else {
            return res.status(401).json({
                authenticated: false,
                mensagem: "Telefone ou senha incorretos."
            });
        }
    } catch (error) {
        console.error("Erro no processamento da rota /auth:", error);
        return res.status(500).json({ 
            mensagem: "Erro interno no servidor.",
            erro: error.message 
        });
    }
});

/**
 * 2. Rota de Cadastro de Novo Usuário (Signin / Registro)
 */
router.post("/signin", async (req, res) => {
    try {
        const apelido = req.body?.apelido || req.body?.nome;
        const telefone = req.body?.telefone;
        const senha = req.body?.senha;

        if (!apelido || !telefone || !senha) {
            return res.status(400).json({
                sucesso: false,
                mensagem: "Nome/Apelido, telefone e senha são obrigatórios."
            });
        }

        const checkCmd = 'SELECT * FROM utilizadores WHERE Telefone = ?';
        const [existing] = await conn.query(checkCmd, [telefone]);

        if (existing.length > 0) {
            return res.status(400).json({
                sucesso: false,
                mensagem: "Este número de telefone já está cadastrado."
            });
        }

        const insertCmd = 'INSERT INTO utilizadores (Apelido, Telefone, Senha) VALUES (?, ?, ?)';
        await conn.query(insertCmd, [apelido, telefone, senha]);

        return res.status(201).json({
            sucesso: true,
            mensagem: "Usuário cadastrado com sucesso!"
        });

    } catch (error) {
        console.error("Erro ao cadastrar usuário:", error);
        return res.status(500).json({ 
            sucesso: false,
            mensagem: "Erro interno no servidor ao cadastrar usuário.",
            erro: error.message 
        });
    }
});

/**
 * 3. Rota para Listar Contatos / Conversas do Usuário
 */
router.get("/contatos", async (req, res) => {
    try {
        const telefone = req.query?.telefone;

        if (!telefone) {
            return res.status(400).json({ mensagem: "Telefone é obrigatório." });
        }

        // Busca todos os números distintos que trocaram mensagens com o usuário logado
        const cmd = `
            SELECT DISTINCT 
                c.TelefoneContato AS Telefone,
                u.Apelido
            FROM (
                SELECT telefone_remetente AS TelefoneContato 
                FROM mensagens 
                WHERE telefone_destinatario = ?
                UNION
                SELECT telefone_destinatario AS TelefoneContato 
                FROM mensagens 
                WHERE telefone_remetente = ?
            ) AS c
            LEFT JOIN utilizadores u ON u.Telefone = c.TelefoneContato
            WHERE c.TelefoneContato != ?
        `;

        const [rows] = await conn.query(cmd, [telefone, telefone, telefone]);
        return res.json(rows);
    } catch (error) {
        console.error("ERRO AO BUSCAR CONTATOS:", error.message);
        return res.status(500).json({ mensagem: "Erro ao buscar contatos.", erro: error.message });
    }
});

/**
 * 4. Rotas de Mensagens
 */
router.get("/chat", async (req, res) => {
    try {
        const telefone = req.query?.telefone;

        if (!telefone) {
            return res.status(400).json({ mensagem: "Telefone é obrigatório." });
        }

        const cmd = 'SELECT * FROM mensagens WHERE telefone_remetente = ? OR telefone_destinatario = ? ORDER BY Id ASC';
        const [rows] = await conn.query(cmd, [telefone, telefone]);

        return res.json(rows);
    } catch (error) {
        console.error("ERRO MYSQL AO BUSCAR MENSAGENS:", error.message);
        return res.status(500).json({ 
            mensagem: "Erro ao buscar mensagens do banco.",
            erro: error.message 
        });
    }
});

router.post("/chat", async (req, res) => {
    try {
        const remetente = req.query?.telefone || req.body?.remetente;
        const destinatario = req.body?.destinatario || req.body?.telefone;
        const mensagem = req.body?.mensagem;

        if (!remetente || !destinatario || !mensagem) {
            return res.status(400).json({ mensagem: "Preencha todos os campos." });
        }

        const cmd = 'INSERT INTO mensagens (telefone_remetente, telefone_destinatario, mensagem) VALUES (?, ?, ?)';
        await conn.query(cmd, [remetente, destinatario, mensagem]);

        return res.json({ mensagem: "Mensagem enviada com sucesso!" });
    } catch (error) {
        console.error("ERRO MYSQL AO ENVIAR MENSAGEM:", error.message);
        return res.status(500).json({ 
            mensagem: "Erro ao salvar mensagem no banco.",
            erro: error.message 
        });
    }
});

module.exports = router;