const express = require('express');
const authRoute = require('./routes/auth.route.js');
const path = require('path');
const cors = require('cors');

const APP = express();

APP.use(cors());
APP.use(express.static(path.join(__dirname, 'front-end')));
APP.use(express.json());
APP.use(express.urlencoded({ extended: true }));


APP.use(authRoute);


APP.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'front-end', 'index.html'));
});

APP.get('/auth', (req, res) => {
    res.sendFile(path.join(__dirname, 'front-end', 'index.html'));
});

APP.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'front-end', 'register.html'));
});

APP.get('/chat-page', (req, res) => {
    res.sendFile(path.join(__dirname, 'front-end', 'chat.html'));
});

const PORT = 3000;
const SERVER = "http://localhost";
const MSG = `Servidor Online em ${SERVER}:${PORT}`;

APP.listen(PORT, () => console.log(MSG));